# Police Duty Rotation — Windows

This package wraps the existing Police Duty Rotation HTML as a Windows desktop application using Electron.

## Cloud build
Upload the project to GitHub, then open **Actions → Build Windows EXE → Run workflow**. The workflow builds both an installer (`.exe`) and a portable `.exe` and uploads them as an artifact.

The HTML is the existing `index.html` from the Police Duty Rotation Android project.
