# Police Duty Rotation — Cloud APK Build

આ projectમાં તમારી original Police Duty Rotation HTML Android WebView appમાં સામેલ છે.

## Android Studio / SDK જરૂરી નથી
GitHub Actions cloud runner Android SDK અને Gradle પોતે setup કરીને APK build કરે છે.

### APK મેળવવાની રીત
1. આ આખું project GitHub પર નવી repositoryમાં upload કરો.
2. Repositoryમાં **Actions** ખોલો.
3. **Build Police Duty Rotation APK** workflow પસંદ કરો.
4. **Run workflow** દબાવો.
5. Build પૂરો થયા પછી **Artifacts → Police-Duty-Rotation-APK** download કરો.
6. ZIPમાંથી `app-debug.apk` કાઢીને Android ફોનમાં install કરો.

દરેક `main` push પર પણ APK આપમેળે build થશે.
