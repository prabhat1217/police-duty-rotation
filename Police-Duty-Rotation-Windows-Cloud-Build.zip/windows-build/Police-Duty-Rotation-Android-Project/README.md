# Police Duty Rotation - Android Studio Project

This project wraps the supplied `nnnn index FINAL-1.html` inside a native Android WebView APK shell. The original HTML is kept in `app/src/main/assets/index.html`.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK/Build Tools requested by Android Studio.
3. Select **Build > Build APK(s)**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.policedutyrotation.app`
Version: 1.0
