# Police Duty Rotation — Windows App

This project packages the supplied final Police Duty Rotation HTML as a real Windows desktop application using Electron.

## Build without Android Studio

1. Upload the contents of this folder to a GitHub repository.
2. Open **Actions** → **Build Windows EXE** → **Run workflow**.
3. When the run finishes, open its **Artifacts** section and download `Police-Duty-Rotation-Windows`.
4. Inside the downloaded artifact is `Police-Duty-Rotation-Windows.exe`.

The application keeps the original HTML as `index.html`; it is not a new replacement interface.
